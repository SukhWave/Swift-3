import UIKit

var greeting = "Third assignment for Swift"

/*
 Create base class Computer with common properties and methods.

 Subclasses Laptop, Desktop, and Server that inherit from Computer and add unique properties and methods.
 A function to display detailed specifications of each computer type.
 Create the Base Class (Computer)

 Add the following properties:
 brand: String
 processor: String
 ram: Int (amount of RAM in GB)
 Create an initializer for these properties.
 Add a method displaySpecs() that prints the values of these properties.
 Create Subclasses:

 Laptop:

 Add an additional property isTouchscreen (a Bool to indicate if the laptop has a touchscreen).
 Override the displaySpecs() method to include this property.
 Desktop:

 Add an additional property hasDedicatedGPU (a Bool to indicate if the desktop has a dedicated GPU).

 Override the displaySpecs() method to include this property.

 Server:

 Add an additional property rackUnits (an Int to specify the server's size in rack units).

 Override the displaySpecs() method to include this property.

 Write some test code:

 Create one object for each subclass (Laptop, Desktop, and Server).
 Assign appropriate values to their properties.
 Call the displaySpecs() method for each object to print their specifications.
 */

//========Base Class=========>>

//====Computer Class====>>
class Computer {
    var brand: String
    var processor: String
    var ram: Int
    
    init(brand: String, processor: String, ram: Int) {
        self.brand = brand
        self.processor = processor
        self.ram = ram
    }
    func displaySpecs() {
        print("Brand: \(brand)")
        print("Processor: \(processor)")
        print("RAM: \(ram) GB")
    }
} //Computer


//============Sub Classes=======>>

//====Laptop====>>
class Laptop: Computer {
    var isTouchscreen: Bool
    
    init(brand: String, processor: String, ram: Int, isTouchscreen: Bool) {
        self.isTouchscreen = isTouchscreen
        super.init(brand: brand, processor: processor, ram: ram)
    }
    override func displaySpecs() {
        print ("Laptop Specifications:")
        print("Brand: \(brand)")
        print("Processor: \(processor)")
        print("RAM: \(ram) GB")
        if isTouchscreen {
            print("Touchscreen: Yes")
        } else {
            print("Touchscreen: No")
        }
        print("\n")
    }
   
} //Laptop


//====Desktop====>>
class Desktop: Computer {
    var hasDedicatedGPU: Bool
    
    init(brand: String, processor: String, ram: Int, hasDedicatedGPU: Bool) {
        self.hasDedicatedGPU = hasDedicatedGPU
        super.init(brand: brand, processor: processor, ram: ram)
       }
    override func displaySpecs() {
        print("Desktop Specifications:")
        print("Brand: \(brand)")
        print("Processor: \(processor)")
        print("RAM: \(ram) GB")
        if hasDedicatedGPU {
            print("Has Dedicated GPU: Yes")
        } else {
            print("Has Dedicated GPU: No")
        }
        print("\n")
    }
} //Desktop


//====Server====>>
class Server: Computer {
    var rackUnits: Int
    
    init(brand: String, processor: String, ram: Int, rackUnits: Int) {
        self.rackUnits = rackUnits
        super.init(brand: brand, processor: processor, ram: ram)
        
    }
    override func displaySpecs() {
        print("Server Specifications:")
        print("Brand: \(brand)")
        print("Processor: \(processor)")
        print("RAM: \(ram) GB")
        print("Rack Units: \(rackUnits)")
    }
} //Server


//====TEST CODE BELOW====>>
var myLaptop = Laptop(brand: "Apple", processor: "M3", ram: 16, isTouchscreen: false)
myLaptop.displaySpecs()
var myDesktop = Desktop(brand: "Dell", processor: "Intel Core i7", ram: 32, hasDedicatedGPU: true)
myDesktop.displaySpecs()
var myServer = Server(brand: "HP", processor: "Xeon", ram: 64, rackUnits: 4)
myServer.displaySpecs()





